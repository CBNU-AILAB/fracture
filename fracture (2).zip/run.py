import csv
import numpy as np
import tensorflow as tf
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from os import getcwd
import os
from tensorflow.keras import layers
import matplotlib.pyplot as plt
import cv2
from models.resnet import fracture_resnet
import shutil
import pandas as pd
# Create an ImageDataGenerator and do Image Augmentation

train_datagen = ImageDataGenerator(
    rescale=1. / 255,
)
validation_datagen = ImageDataGenerator(
    rescale=1. / 255)

train_dir = os.getcwd()+'/dataset/radiograph_excel/train'
test_dir = os.getcwd()+'/dataset/radiograph_excel/test'

df = pd.read_csv(train_dir+"/train/imageLists.csv")
df1 = pd.read_csv(test_dir+"/test/imageLists.csv")
train_generator = train_datagen.flow_from_dataframe(
    dataframe=df,
    directory=train_dir+"/train",
    x_col = 'filename',
    y_col= 'tags',
    target_size=(256, 256),
    class_mode='categorical')
validation_generator = validation_datagen.flow_from_dataframe(
    dataframe=df1,
    directory=test_dir+"/test",
    x_col = 'filename',
    y_col= 'tags',
    target_size=(256, 256),
    class_mode=None)



# class CategoryCrossing: Category crossing layer.
#
# class CategoryEncoding: Category encoding layer.
#
# class CenterCrop: Crop the central portion of the images to target height and width.
#
# class Discretization: Buckets data into discrete ranges.
#
# class Hashing: Implements categorical feature hashing, also known as "hashing trick".
#
# class IntegerLookup: Maps integers from a vocabulary to integer indices.
#
# class Normalization: Feature-wise normalization of the data.
#
# class PreprocessingLayer: Base class for PreprocessingLayers.
#
# class RandomContrast: Adjust the contrast of an image or images by a random factor.
#
# class RandomCrop: Randomly crop the images to target height and width.
#
# class RandomFlip: Randomly flip each image horizontally and vertically.
#
# class RandomHeight: Randomly vary the height of a batch of images during training.
#
# class RandomRotation: Randomly rotate each image.
#
# class RandomTranslation: Randomly translate each image during training.
#
# class RandomWidth: Randomly vary the width of a batch of images during training.
#
# class RandomZoom: Randomly zoom each image during training.
#
# class Rescaling: Multiply inputs by scale and adds offset.
#
# class Resizing: Image resizing layer.
#
# class StringLookup: Maps strings from a vocabulary to integer indices.
#
# class TextVectorization: Text vectorization layer.
# 크기 변경(Size Reshape) 80% or 90% or 100% or 110% or 120%
# 회전(Rotate) 3° or 6° or … or 30°
# 반전(Flip) False or 좌우반전
# 이동(Translate) 상하 : -8%∼8%, 좌우 : -12%∼12%
# 자르기(Crop) 중앙 기반 자르기(Center based Cropping)
# 잡음(Noise) 점 잡음(Salt and Pepper Noise) 각 기준들을 무작위로 선택하여 사용, 이미지의 크기또한 변경될 수 있음 (모두 다 실행)

data_augmentation = tf.keras.Sequential([
    layers.experimental.preprocessing.RandomFlip("horizontal_and_vertical"),
    layers.experimental.preprocessing.RandomRotation(factor=(0.03, 0.3)),
    layers.experimental.preprocessing.RandomCrop(height=80, width=80),
    layers.experimental.preprocessing.RandomTranslation(height_factor=[-0.08, 0.08], width_factor=(-0.12, 0.12), fill_mode='nearest'),
    layers.GaussianNoise(0.2),
])
model = tf.keras.Sequential([
    data_augmentation,
    fracture_resnet(),
])
model.compile(optimizer = tf.keras.optimizers.Adam(),
              loss = 'categorical_crossentropy',
              metrics=['accuracy'])
history = model.fit(
    train_generator,
    epochs=200,
    verbose=1,
    validation_data = validation_generator,
)

#
# # Plot the chart for accuracy and loss on both training and validation
#
# acc = history.history['accuracy']
# val_acc = history.history['val_accuracy']
# loss = history.history['loss']
# val_loss = history.history['val_loss']
#
# epochs = range(len(acc))
#
# plt.plot(epochs, acc, 'r', label='Training accuracy')
# plt.plot(epochs, val_acc, 'b', label='Validation accuracy')
# plt.title('Training and validation accuracy')
# plt.legend()
# plt.figure()
#
# plt.plot(epochs, loss, 'r', label='Training Loss')
# plt.plot(epochs, val_loss, 'b', label='Validation Loss')
# plt.title('Training and validation loss')
# plt.legend()
#
# plt.show()

